# Contoh Skrip Biodata HTML dan CSS

![gambar](https://raw.githubusercontent.com/febrihidayan/contoh-skrip-biodata-html-css/main/febrihidayan.png)